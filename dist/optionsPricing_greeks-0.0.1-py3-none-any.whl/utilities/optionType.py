from enum import Enum

class OptionType(Enum):
    CALL = 1
    PUT = -1